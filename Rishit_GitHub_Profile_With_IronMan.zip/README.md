# RISHIT PATHAK

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="./dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="./light.svg">
  <img src="./dark.svg" alt="RISHIT PATHAK — SOFTWARE DEVELOPER · AI/ML · FULL-STACK">
</picture>


## Profile

<img src="./profile-photo.png" width="180" alt="Rishit Pathak profile visual">

## `./profile.sh`

Computer Science undergraduate at **Kalinga Institute of Industrial Technology (KIIT)** with a strong foundation in **Data Structures & Algorithms and core computer science concepts**. Solved **150+ problems on LeetCode** and currently building hands-on AI/ML and computer-vision projects with Python, YOLOv8 and OpenCV.

## Focus

- Software Development
- Data Structures & Algorithms
- AI / Machine Learning
- Computer Vision
- Full-Stack / Web Development
- Large Language Model fundamentals

## Engineering Stack

**Languages**  
`C` `C++` `Python` `Java` `SQL`

**Web**  
`HTML` `CSS` `JavaScript`

**AI / ML & Computer Vision**  
`YOLOv8` `OpenCV` `Machine Learning` `LLM Fundamentals`

**Core CS**  
`DSA` `OOP` `DBMS` `Operating Systems`

**Tools & Platforms**  
`Git` `GitHub` `VS Code` `Netlify`

## Featured Projects

### EduNova — AI-based Attendance & Engagement System
Computer-vision-based attendance and engagement system using **Python and OpenCV**, with real-time face detection and recognition. Currently in progress.

### Tomato Leaf Disease Detection
Built and trained a **YOLOv8** computer-vision model for multiclass tomato leaf disease detection.

### Personal HealthTracker
Responsive web application for tracking daily health metrics including steps, calories and water intake, built with **HTML, CSS and JavaScript** and deployed on **Netlify**.

## Achievements

- **India Innovates 2026 finalist**, with an innovative solution presented at the national stage at Bharat Mandapam.
- **150+ LeetCode problems solved.**
- Building hands-on experience in Machine Learning and Large Language Models.

## Leadership

**Coding Ninjas KIIT Chapter — Administration Team Member**

- Coordinated ID card management and event logistics.
- Contributed to marketing and student outreach.
- Participated in the freshers recruitment drive by interviewing and evaluating student candidates.

## Education

**Kalinga Institute of Industrial Technology (KIIT)**  
B.Tech — Computer Science & Engineering · Aug 2024 – Present

**Rajkamal Saraswati Vidya Mandir, Dhanbad**  
CBSE · Class XII · 2024

**De Nobili School C.M.R.I, Dhanbad**  
ICSE · Class X · 2022

---

<p align="center">
  <code>build --learn --ship</code>
</p>
